import firebase from 'firebase';

// add SDK Firebase
var firebaseConfig = {
apiKey: "AIzaSyDtLWfXzqHxBKOd5W5rxoCqtV6UNoI3dmY",

  authDomain: "c-58pro.firebaseapp.com",

  databaseURL: "https://c-58pro-default-rtdb.firebaseio.com",

  projectId: "c-58pro",

  storageBucket: "c-58pro.appspot.com",

  messagingSenderId: "91583077390",

  appId: "1:91583077390:web:21b08e9de8f2a7b1b1b05f"

};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);

export default firebase.database();